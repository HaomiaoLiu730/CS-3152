## CS 3152
TEAM 6: TEAM OCTAVE ( LUCAS JAMES CUSATI | YIHENG DONG | HAOMIAO LIU | 
SIRIUS LIU | JUNXI SONG | JULIANE PHOEBE TSAI | XIAOYAO YAO | ZILI ZHOU )  
GAME: BEAR WITH ME

CONTROLS:  
A/LEFT KEY: move left  
D/RIGHT KEY: move right  
W/UP KEY: jump  
MOUSE CLICK: drag to determine the angle of throwing, hold to determine the strength and then release the mouse to throw out a penguin  
SPACE BAR: cancel the throw  
*Collect notes by throwing penguins to them to pass the level  
*Penguins will be automatically picked back within a short distance  
*Once a note is hit by a penguin, the corresponding penguin disappears  
*When using the level editor, start putting tiles from the left, make the ground continuous, and surround water with grounds
